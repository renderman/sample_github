'use strict';

angular.module('security.login', [])

.config(['$routeProvider', function($routeProvider){

  $routeProvider.when('/login', {
    templateUrl:'/views/login/login.html',
    controller:'LoginController'
  });
}])

/**
 * @ngdoc function
 * @name LoginController
 * @description
 * # LoginController
 * 
 */
.controller('LoginController', ['$scope', '$location', 'authService', function ($scope, $location, authService) {

    $scope.loginData = {
        userName: '',
        password: ''
    };

    $scope.message = '';

    $scope.login = function () {

        authService.login($scope.loginData).then(function (response) {

            console.log('login pushed!!');
            $location.path('/feeds');

        },
         function (err) {
             $scope.message = err.error_description;
             console.log('login error!!');
         });
    };

}]);
