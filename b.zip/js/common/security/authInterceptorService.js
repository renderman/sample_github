'use strict';

angular.module('security.interceptor', ['LocalStorageModule'])

/**
 * @ngdoc object
 * @name TakTakApp.service:securityInterceptor
 * @description
 * 
 */
.factory('securityInterceptor', ['$q', '$injector','$location', 'localStorageService', function ($q, $injector,$location, localStorageService) {

    var authInterceptorServiceFactory = {};

    // Intercept a request by implementing the request function. called before $http sends the request to the backend.
    var _request = function (config) {

        config.headers = config.headers || {};
       
        var authData = localStorageService.get('authorizationData');
        if (authData) {
            config.headers.Authorization = 'Bearer ' + authData.token;
        }

        return config;
    };

    // Intercept response error by implementing the responseError function. backend call fail
    var _responseError = function (rejection) {
        
        if (rejection.status === 401) {
            var authService = $injector.get('authService');
            
            authService.logOut();
            $location.path('/login');
        }

        return $q.reject(rejection);
    };

    authInterceptorServiceFactory.request = _request;
    authInterceptorServiceFactory.responseError = _responseError;

    return authInterceptorServiceFactory;
}])

// interceptor設定、トークンをヘッダーに設定、権限のない場合ログイン画面へ遷移
.config(['$httpProvider', function($httpProvider) {
  $httpProvider.interceptors.push('securityInterceptor');
}]);
