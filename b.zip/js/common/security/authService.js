'use strict';

angular.module('security.service', ['LocalStorageModule'])

/**
 * @ngdoc object
 * @name TakTakApp.service:authService
 * @description
 * 
 */
.factory('authService', ['$http', '$q', '$location', 'localStorageService', 'SERVER_CONFIG', function ($http, $q, $location, localStorageService, SERVER_CONFIG) {

    var serviceBase = SERVER_CONFIG.apiServiceBaseUri;
    var authServiceFactory = {};

    var _authentication = {
        isAuth: false,
        userName: ""
    };

    // Redirect to the given url (defaults to '/')
    function redirect(url) {
        url = url || '/feeds/';
        $location.path(url);
    }

    var _saveRegistration = function (registration) {

        _logOut();

        return $http.post(serviceBase + 'api/account/register', registration).then(function (response) {
            // success
            return response;
        });

    };

    var _login = function (loginData) {

        var data = "grant_type=password&username=" + loginData.userName + "&password=" + loginData.password;
        //var data = { 'grant_type': 'password', 'username': loginData.userName, 'password': loginData.password };

        var deferred = $q.defer();

        // $http({
        //     method: 'POST',
        //     url: serviceBase + 'oauth/token', 
        //     data: data, 
        //     headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        //     withCredentials: true
        //     }).success(function (response) {

        //     localStorageService.set('authorizationData', { token: response.access_token, userName: loginData.userName, refreshToken: "", useRefreshTokens: false });

        //     _authentication.isAuth = true;
        //     _authentication.userName = loginData.userName;

        //     deferred.resolve(response);

        // }).error(function (err, status) {
        //     _logOut();
        //     deferred.reject(err);
        // });

        // TODO For Test!!!
        _authentication.isAuth = true;
        _authentication.userName = 'tempUser';
        localStorageService.set('authorizationData', { token: 'xxx', userName: 'tempUser', refreshToken: 'xxx', useRefreshTokens: false });
        deferred.resolve(true);

        return deferred.promise;

    };

    var _logOut = function () {

        localStorageService.remove('authorizationData');

        _authentication.isAuth = false;
        _authentication.userName = "";

        redirect('/login');

    };

    var _fillAuthData = function () {

        var authData = localStorageService.get('authorizationData');
        if (authData) {
            _authentication.isAuth = true;
            _authentication.userName = authData.userName;
        }
        console.log('fillAuthData!!');
    };

    var _initTransition = function () { 
        if (_authentication.isAuth) {
          redirect();
          console.log('Logined!!');
        } else {
          redirect('/login');
          console.log('Not logined!!');
        }
    };

    authServiceFactory.saveRegistration = _saveRegistration;
    authServiceFactory.login = _login;
    authServiceFactory.logOut = _logOut;
    authServiceFactory.fillAuthData = _fillAuthData;
    authServiceFactory.authentication = _authentication;
    authServiceFactory.initTransition = _initTransition;

    return authServiceFactory;
}]);