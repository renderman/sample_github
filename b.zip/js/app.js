'use strict';

/**
 * @ngdoc overview
 * @name TakTak
 * @description
 * Main module of the application.
 */

angular.module('TakTakApp', [
  'ngRoute',
  'feeds',
  'security']);

// サーバ環境設定
angular.module('TakTakApp').constant('SERVER_CONFIG', {
  apiServiceBaseUri: 'http://130.1.60.35:3000/'
});

angular.module('TakTakApp').config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
  $locationProvider.html5Mode(true);
  $routeProvider.otherwise({redirectTo:'/'});
}]);

// CORS対応
angular.module('TakTakApp').config(['$httpProvider', function($httpProvider) {
  $httpProvider.defaults.useXDomain = true;
  $httpProvider.defaults.headers.common = 'Content-Type: application/json';
  delete $httpProvider.defaults.headers.common['X-Requested-With'];
}]);

angular.module('TakTakApp').run(['authService', function(authService) {
  authService.fillAuthData();
}]);

angular.module('TakTakApp').controller('AppController', ['$scope', '$location', 'authService', function($scope, $location, authService) {

    authService.initTransition();

    $scope.authentication = authService.authentication;

}]);

angular.module('TakTakApp').controller('FooterController', ['$scope', 'authService', function ($scope, authService) {

    $scope.logOut = function () {
        authService.logOut();
        console.log('logout pushed!!');
    }

    $scope.authentication = authService.authentication;
   
}]);