'use strict';

angular.module('feeds', ['ngResource']) 

.config(['$routeProvider', function($routeProvider){

  $routeProvider.when('/feeds', {
    templateUrl:'/views/feeds/index.html',
    controller:'FeedsIndexCtrl'
  });

    $routeProvider.when("/feeds/new", {
        controller: "FeedsNewCtrl",
        templateUrl: "/views/feeds/new.html"
    });

}])

/**
 * @ngdoc function
 * @name FeedController
 * @description
 * # FeedController
 * 
 */
.controller('FeedsIndexCtrl', ['$scope', '$resource',function ($scope,$resource) {

        var feeds = $resource("./data/feeds/index.json")
        $scope.feeds = feeds.query();

    }]).controller('FeedsNewCtrl', ['$scope', function ($scope) {

    }]);
