'use strict';

/**
 * @ngdoc overview
 * @name TakTakAuthApp
 * @description
 * Main module of the application.
 */
var app = angular.module('TakTakAuthApp', ['ngRoute', 'LocalStorageModule']);

app.config(function ($routeProvider) {

    $routeProvider.when("/home", {
        controller: "HomeCtrl",
        templateUrl: "views/home.html"
    });

    $routeProvider.when("/login", {
        controller: "LoginCtrl",
        templateUrl: "views/login.html"
    });

    $routeProvider.when("/signup", {
        controller: "SignupCtrl",
        templateUrl: "views/signup.html"
    });

    $routeProvider.when("/feeds", {
        controller: "FeedsCtrl",
        templateUrl: "views/feeds.html"
    });

    $routeProvider.otherwise({ redirectTo: "/home" });

});

//var serviceBase = 'http://localhost:3000/';
var serviceBase = 'http://130.1.60.35:3000/';
app.constant('ngAuthSettings', {
    apiServiceBaseUri: serviceBase,
    //clientId: 'xxx'
});

app.config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        $httpProvider.defaults.headers.common = 'Content-Type: application/json';
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    }
]);

// The $httpProvider provider contains an array of interceptors. 
// An interceptor is simply a regular service factory that is registered to that array.
app.config(function ($httpProvider) {
    $httpProvider.interceptors.push('authInterceptorService');
});

app.run(['authService', function (authService) {
    authService.fillAuthData();
}]);