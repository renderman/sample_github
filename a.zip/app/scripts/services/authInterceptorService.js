'use strict';

/**
 * @ngdoc object
 * @name TakTakAuthApp.service:authInterceptorService
 * @description
 * 
 */
app.factory('authInterceptorService', ['$q', '$injector','$location', 'localStorageService', function ($q, $injector,$location, localStorageService) {

    var authInterceptorServiceFactory = {};

    // Intercept a request by implementing the request function. called before $http sends the request to the backend.
    var _request = function (config) {

        config.headers = config.headers || {};
       
        var authData = localStorageService.get('authorizationData');
        if (authData) {
            config.headers.Authorization = 'Bearer ' + authData.token;
        }

        return config;
    };

    // Intercept response error by implementing the responseError function. backend call fail
    var _responseError = function (rejection) {
        
        if (rejection.status === 401) {
            var authService = $injector.get('authService');
            
            authService.logOut();
            $location.path('/login');
        }

        return $q.reject(rejection);
    };

    authInterceptorServiceFactory.request = _request;
    authInterceptorServiceFactory.responseError = _responseError;

    return authInterceptorServiceFactory;
}]);