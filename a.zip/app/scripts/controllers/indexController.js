'use strict';

/**
 * @ngdoc function
 * @name TakTakAuthApp.controller:IndexCtrl
 * @description
 * # IndexCtrl
 * 
 */
app.controller('IndexCtrl', ['$scope', '$location', 'authService', function ($scope, $location, authService) {

	$scope.logOut = function () {
        authService.logOut();
        $location.path('/home');
    }

    $scope.authentication = authService.authentication;
   
}]);