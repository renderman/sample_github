'use strict';

/**
 * @ngdoc function
 * @name TakTakAuthApp.controller:HomeCtrl
 * @description
 * # HomeCtrl
 * 
 */
app.controller('HomeCtrl', ['$scope', function ($scope) {
   
}]);