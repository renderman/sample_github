'use strict';

/**
 * @ngdoc function
 * @name TakTakAuthApp.controller:LoginCtrl
 * @description
 * # LoginCtrl
 * 
 */
app.controller('LoginCtrl', ['$scope', '$location', 'authService', 'ngAuthSettings', function ($scope, $location, authService, ngAuthSettings) {

    $scope.loginData = {
        userName: '',
        password: ''
    };

    $scope.message = '';

    $scope.login = function () {

        authService.login($scope.loginData).then(function (response) {

            $location.path('/feeds');$scope.message='ok';console.log(authService.authentication.isAuth);

        },
         function (err) {
             $scope.message = err.error_description;$scope.message='bad';console.log('bad');
         });
    };

}]);
