'use strict';

/**
 * @ngdoc function
 * @name loginExamApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the loginExamApp
 */
angular.module('loginExamApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
