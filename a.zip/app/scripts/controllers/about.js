'use strict';

/**
 * @ngdoc function
 * @name loginExamApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the loginExamApp
 */
angular.module('loginExamApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
