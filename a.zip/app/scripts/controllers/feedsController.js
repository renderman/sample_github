'use strict';

/**
 * @ngdoc function
 * @name TakTakAuthApp.controller:FeedsCtrl
 * @description
 * # FeedsCtrl
 * 
 */
app.controller('FeedsCtrl', ['$scope', function ($scope) {
   
}]);